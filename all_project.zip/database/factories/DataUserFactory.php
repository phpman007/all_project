<?php

use Faker\Generator as Faker;

$factory->define(App\DataUser::class, function (Faker $faker) {
    return [
        //
    ];
});
