<?php

use Faker\Generator as Faker;

$factory->define(App\Models\GroupData::class, function (Faker $faker) {
    return [
        //
    ];
});
