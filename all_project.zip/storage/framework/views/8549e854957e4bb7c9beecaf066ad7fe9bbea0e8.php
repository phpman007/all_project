<?php $__env->startSection('content'); ?>
  <nav aria-label="breadcrumb" style="font-size:12px">
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">หน้าแรก</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(url('save-data')); ?>">บันทึกรายการข้อมูล</a></li>
      <li class="breadcrumb-item active" aria-current="page">
        Add & Edit Group Data
      </li>
    </ol>
  </nav>
    <br>

    <h2 class="header-h">Add & Edit Group Data</h2>
    <div class="row">
      <div class="col-lg-12 col-md-12 mx-auto">
        
        
        <?php if(!empty($item)): ?>
        <?php echo e(Form::open(['url'=>route('group-data.update', $item->id),'method'=>'PUT'])); ?>

      <?php else: ?>
        <?php echo e(Form::open(['url'=>route('group-data.store'),'method'=>'POST'])); ?>

      <?php endif; ?>
          <div class="control-group">
            <div class="form-group floating-label-form-group controls <?php echo e(old('email') != null ? 'floating-label-form-group-with-value' : ''); ?> <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>">
              <label>Title</label>
              <?php if($errors->has('Title')): ?>
                <div class="is-valide-message">
                  <?php echo e($errors->first('Title')); ?>

                </div>
              <?php endif; ?>
              <?php echo e(Form::text('title', $item->title, ['class'=>"form-control", 'placeholder'=>"Title"])); ?>

              <p class="help-block text-danger"></p>
            </div>
          </div>

          <div class="control-group">
            <div class="form-group floating-label-form-group controls  floating-label-form-group-with-value <?php echo e($errors->has('password') ? 'is-invalid' : ''); ?>">
              <label>Publish</label>
              <?php if($errors->has('publish')): ?>
                <div class="is-valide-message">
                  <?php echo e($errors->first('publish')); ?>

                </div>
              <?php endif; ?>

              <?php echo e(Form::select('publish', ['0' =>'Disable', '1'=>'Enable'],$item->publish, ['class'=>"form-control"])); ?>


              <p class="help-block text-danger"></p>
            </div>
          </div>


          <br>
          <div id="success"></div>
          <div class="form-group">
            <button type="submit" class="btn btn-primary" id="">Save</button>
          </div>
          <table class="table table-bordered" style="font-size:14px">
            <thead>
              <tr>
                <th>Title</th>
                <th width="100">Publish</th>
                <th width="80">Id</th>
                <th width="200">action</th>
              </tr>
            </thead>
            <tbody>

              <?php echo e(Form::close()); ?>

            <?php if($items->count() == 0): ?>
              <tr>
                <td colspan="3">No data...</td>
              </tr>
            <?php endif; ?>
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($value->title); ?> </td>
                <td><small style="font-style: italic;"><?php echo e($value->publish ==0 ? 'Disable' : 'Enable'); ?></small></td>
                <td><?php echo e($value->id); ?></td>
                <td>
                  <a href="<?php echo e(route('group-data.edit', $value->id)); ?>">update</a>
                  <?php echo e(Form::open(['method'=>"delete", 'style'=>'display:inline-block', 'url'=>route('group-data.destroy', $value->id)])); ?>


                  <?php echo e(Form::submit('delete', ['style'=>'padding: 0px 5px;','class'=>'btn btn-danger'])); ?>

                  <?php echo e(Form::close()); ?>

                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>

          <?php echo e($items->render()); ?>

      </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>