<?php $__env->startSection('content'); ?>
    <br>
    <?php if(!Auth::check()): ?>
    <h2 class="header-h">Sign in</h2>
    <div class="row">
      <div class="col-lg-8 col-md-10 mx-auto">
        
        
        <?php echo e(Form::open(['method'=>'POST'])); ?>

          <div class="control-group">
            <div class="form-group floating-label-form-group controls <?php echo e(old('email') != null ? 'floating-label-form-group-with-value' : ''); ?> <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>">
              <label>Email</label>
              <?php if($errors->has('email')): ?>
                <div class="is-valide-message">
                  <?php echo e($errors->first('email')); ?>

                </div>
              <?php endif; ?>
              <?php echo e(Form::text('email', null, ['class'=>"form-control", 'placeholder'=>"Email"])); ?>

              <p class="help-block text-danger"></p>
            </div>
          </div>

          <div class="control-group">
            <div class="form-group floating-label-form-group controls  <?php echo e(old('password') != null ? 'floating-label-form-group-with-value' : ''); ?> <?php echo e($errors->has('password') ? 'is-invalid' : ''); ?>">
              <label>Password</label>
              <?php if($errors->has('password')): ?>
                <div class="is-valide-message">
                  <?php echo e($errors->first('password')); ?>

                </div>
              <?php endif; ?>

              <?php echo e(Form::password('password', ['class'=>"form-control", 'placeholder'=>"Password"])); ?>


              <p class="help-block text-danger"></p>
            </div>
          </div>


          <br>
          <div id="success"></div>
          <div class="form-group">
            <button type="submit" class="btn btn-primary" id="">Login</button>
          </div>
          <div class="form-group">
            <a href="<?php echo e(url('register')); ?>" class="pull-left" id="">สมัครใช้บริการ</a>
            <a href="<?php echo e(url('forget-password')); ?>" class="pull-right" id="">ลืม Password</a>
          </div>
        <?php echo e(Form::close()); ?>

      </div>
    </div>
  <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>