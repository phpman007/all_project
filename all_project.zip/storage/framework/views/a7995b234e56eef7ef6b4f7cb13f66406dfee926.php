<?php $__env->startSection('content'); ?>
  <nav aria-label="breadcrumb" style="font-size:12px">
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">หน้าแรก</a></li>
      <li class="breadcrumb-item active" aria-current="page">
        <?php if(!isset($user)): ?>
          สมัครใช้บริการ
        <?php else: ?>
          แก้ไขข้อมูลส่วนตัว
        <?php endif; ?>
      </li>
    </ol>
  </nav>
  <br>
  <h2 class="header-h">
    <?php if(!isset($user)): ?>
      สมัครใช้บริการ
    <?php else: ?>
      แก้ไขข้อมูลส่วนตัว
    <?php endif; ?>
    </h2>
  <div class="row">
    <div class="col-lg-8 col-md-10 mx-auto">
      <form name="sentMessage" method="POST" id="contactForm" novalidate="">
        <?php echo csrf_field(); ?>

        <div class="control-group">
          <div class="form-group  floating-label-form-group controls <?php echo e(old('name') != null || isset($user)  ? 'floating-label-form-group-with-value' : ''); ?> <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>">
            <label>ชื่อ - นามสกุล</label>
            <?php if($errors->has('name')): ?>
              <div class="is-valide-message">
                <?php echo e($errors->first('name')); ?>

              </div>
            <?php endif; ?>
            <?php echo Form::text('name', $user->name, [
              'class' => "form-control",
              'placeholder' => "ชื่อ - นามสกุล"
              ]); ?>


              <p class="help-block text-danger"></p>
            </div>
          </div>

          <div class="control-group">
            <div class="form-group floating-label-form-group controls <?php echo e(old('province') != null || isset($user)  ? 'floating-label-form-group-with-value' : ''); ?> <?php echo e($errors->has('province') ? 'is-invalid' : ''); ?>">
              <label>จังหวัดที่ท่านอาศัยอยู่</label>
              <?php if($errors->has('province')): ?>
                <div class="is-valide-message">
                  <?php echo e($errors->first('province')); ?>

                </div>
              <?php endif; ?>
              <?php echo Form::text('province', $user->province, [
                'class' => "form-control",
                'placeholder' => "จังหวัดที่ท่านอาศัยอยู่"
                ]); ?>


                <p class="help-block text-danger"></p>
              </div>
            </div>

            <div class="control-group">
              <div class="form-group floating-label-form-group controls <?php echo e(old('email') != null || isset($user) ? 'floating-label-form-group-with-value' : ''); ?> <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>">
                <label>Email</label>
                <?php if($errors->has('email')): ?>
                  <div class="is-valide-message">
                    <?php echo e($errors->first('email')); ?>

                  </div>
                <?php endif; ?>
                <?php if($user == null): ?>
                  <?php echo Form::text('email', $user->email, [
                    'class' => "form-control",
                    'placeholder' => "Email"
                    ]); ?>

                  <?php else: ?>
                    <?php echo e($user->email); ?>

                  <?php endif; ?>
                  <p class="help-block text-danger "></p>
                </div>
              </div>

              <div class="control-group">
                <div class="form-group floating-label-form-group controls <?php echo e(old('password') != null || isset($user)  ? 'floating-label-form-group-with-value' : ''); ?> <?php echo e($errors->has('password') ? 'is-invalid' : ''); ?>">
                  <label>Password</label>
                  <?php if($errors->has('password')): ?>
                    <div class="is-valide-message">
                      <?php echo e($errors->first('password')); ?>

                    </div>
                  <?php endif; ?>
                  <?php echo e(Form::password('password', [
                    'class' => "form-control",
                    'placeholder' => "Password"
                    ] )); ?>


                    <p class="help-block text-danger"></p>
                  </div>
                </div>

                <div class="control-group">
                  <div class="form-group floating-label-form-group controls <?php echo e(old('password_confirmation') != null || isset($user)  ? 'floating-label-form-group-with-value' : ''); ?> <?php echo e($errors->has('password_confirmation') ? 'is-invalid' : ''); ?>">
                    <label>Confirm Password</label>
                    <?php if($errors->has('password_confirmation')): ?>
                      <div class="is-valide-message">
                        <?php echo e($errors->first('password_confirmation')); ?>

                      </div>
                    <?php endif; ?>
                    <?php echo e(Form::password('password_confirmation', [
                      'class' => "form-control",
                      'placeholder' => "Confirm Password"
                      ] )); ?>

                      <p class="help-block text-danger"></p>
                    </div>
                  </div>


                  <br><br>
                  <h5 class="header-h">คำถาม คำตอบกู้ Password</h5>

                  <div class="control-group">
                    <div class="form-group floating-label-form-group controls <?php echo e(old('question_forget_password') != null || isset($user)  ? 'floating-label-form-group-with-value' : ''); ?> <?php echo e($errors->has('question_forget_password') ? 'is-invalid' : ''); ?>">
                      <label>คำถาม</label>
                      <?php if($errors->has('question_forget_password')): ?>
                        <div class="is-valide-message">
                          <?php echo e($errors->first('question_forget_password')); ?>

                        </div>
                      <?php endif; ?>
                      <?php echo Form::text('question_forget_password', $user->question_forget_password, [
                        'class' => "form-control",
                        'placeholder' => "คำถาม"
                        ]); ?>

                        <p class="help-block text-danger"></p>
                      </div>
                    </div>

                    <div class="control-group">
                      <div class="form-group floating-label-form-group controls <?php echo e(old('answer_forget_password') != null || isset($user)  ? 'floating-label-form-group-with-value' : ''); ?> <?php echo e($errors->has('answer_forget_password') ? 'is-invalid' : ''); ?>">
                        <label>คำตอบ</label>
                        <?php if($errors->has('answer_forget_password')): ?>
                          <div class="is-valide-message">
                            <?php echo e($errors->first('answer_forget_password')); ?>

                          </div>
                        <?php endif; ?>
                        <?php echo Form::text('answer_forget_password', $user->answer_forget_password, [
                          'class' => "form-control",
                          'placeholder' => "คำตอบ"
                          ]); ?>


                          <p class="help-block text-danger"></p>
                        </div>
                      </div>
                      <br>
                      <div class="row">
                        <div class="col-md-12">
                          <div class="control-group">
                            <div class="form-group ">
                              <?php if($errors->has('agree')): ?>
                                <div class="is-valide-message" style="bottom: 0px;font-size: 12px;">
                                  <?php echo e($errors->first('agree')); ?>

                                </div>
                              <?php endif; ?>
                              <?php if(!isset($user)): ?>
                                <label class="container-checkbox"> I have read and agree to the
                                  <a href="#"data-toggle="collapse" data-target="#collapse">Terms of Service</a>
                                  <input name="agree" type="checkbox" value='1'>
                                  <span class="checkmark"></span>
                                </label>

                                <div id="collapse" class="collapse" style="margin-top:15px">
                                  <div class="card card-body">
                                    <?php echo config('fields.policy'); ?>

                                  </div>
                                </div>
                              <?php endif; ?>
                            </div>
                          </div>
                        </div>
                      </div>
                      <br>
                      <div id="success"></div>
                      <div class="form-group">
                        <button type="submit" class="btn btn-primary" id="">

                          <?php if(!isset($user)): ?>
                            ลงทะเบียน
                          <?php else: ?>
                            บันทึก
                          <?php endif; ?>
                        </button>
                      </div>
                      <br>

                      <?php if(!isset($user)): ?>
                      <div class="form-group">
                        <a href="<?php echo e(url('register')); ?>" class="pull-left" id="">เข้าสู่ระบบ</a>
                        <a href="<?php echo e(url('forget-password')); ?>" class="pull-right" id="">ลืม Password</a>
                      </div>
                    <?php endif; ?>
                    </form>
                  </div>
                </div>
              <?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>