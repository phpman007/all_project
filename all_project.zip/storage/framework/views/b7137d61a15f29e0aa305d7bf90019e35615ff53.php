<?php $__env->startSection('content'); ?>
  <nav aria-label="breadcrumb" style="font-size:12px">
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">หน้าแรก</a></li>
      <li class="breadcrumb-item active" aria-current="page">
        ข้อเสนอแนะ
      </li>
    </ol>
  </nav>
  <br>
  <h2 class="header-h">
    ข้อเสนอแนะ
    <?php if(Auth::guard('admin')->check()): ?>
      <small><a href="suggestion/edit">แก้ไขข้อมูล</a></small>
    <?php endif; ?>
  </h2>
  <div class="row">
    <div class="col-lg-12 col-md-10 mx-auto">
<?php echo File::get(public_path('suggestion.txt')); ?>

    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>