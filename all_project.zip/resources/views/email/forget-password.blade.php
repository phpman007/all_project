<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <h3>แจ้งเตื่อน ท่านได้ทำการรีรหัสผ่าน</h3>
รหัสผ่านใหม่ของท่านคือ {{$data->str_password}}
  </body>
</html>
